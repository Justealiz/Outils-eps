# Relevé de zones — Badminton EPS

Application web autonome (HTML/CSS/JS), sans backend, pour relever les zones du
terrain atteintes par le volant en badminton, avec gestion des bonus, des
conditions spéciales (fautes, sorties…), des groupes d'élèves, des statistiques
et de l'export Excel.

## Contenu du dossier

- `index.html` — structure de la page
- `style.css` — mise en forme
- `app.js` — logique de l'application (configuration, observation, statistiques, export)
- `manifest.json` — manifeste de l'application (icône/installation)
- `netlify.toml` — configuration de déploiement Netlify

## Déploiement sur Netlify

### Option 1 — Glisser-déposer (le plus simple)
1. Aller sur [app.netlify.com/drop](https://app.netlify.com/drop)
2. Glisser ce dossier entier dans la fenêtre
3. L'application est en ligne en quelques secondes, avec une URL fournie par Netlify

### Option 2 — Dépôt Git
1. Pousser ce dossier dans un dépôt GitHub/GitLab/Bitbucket
2. Sur Netlify : « Add new site » → « Import an existing project »
3. Sélectionner le dépôt — aucune commande de build n'est nécessaire
   (le fichier `netlify.toml` indique de publier le dossier racine `.`)

## Confidentialité (RGPD)

Toutes les données (élèves, résultats) sont stockées **uniquement dans le
navigateur** (localStorage) de l'appareil utilisé. Aucune donnée n'est envoyée
à un serveur. Pensez à exporter les résultats en Excel et à effacer les
données depuis l'onglet « Statistiques & export » en fin de cycle.
